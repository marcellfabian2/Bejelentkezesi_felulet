const belepesGomb = document.querySelector("#belepes-gomb");
const regisztracioGomb = document.querySelector("#regisztracio-gomb");
const kontener = document.querySelector(".kontener");

regisztracioGomb.addEventListener("click", function() {
  kontener.classList.add("regisztracio-mod");
});

belepesGomb.addEventListener("click", function() {
  kontener.classList.remove("regisztracio-mod");
});
